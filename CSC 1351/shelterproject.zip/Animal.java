/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shelterproject;

/**
 *
 * @author llafau1
 */
public class Animal implements Comparable<Animal>{
    private String name;
    private String kind;
    private double age;
    
    //This is the constructor 
    public Animal(String name, String species, double age)
    {
        this.name = name;
        kind = species;
        this.age = age;
    }
    
    //This prints out the name, age, and kind of animal
    public void printInfo()
    {
       if(age < 1)
       {
           System.out.printf("%-10s%.1f months%5s%s\n", kind, age * 12, " ", name);
       }
       else
       {
           System.out.printf("%-10s%.1f years%6s%s\n", kind, age, " ", name);
       }
    }
    
    //This compares the kind of animal then the age if the kind is the same and then the name if the ages are the same 
    public int compareTo(Animal other)
    {
        if(kind.compareTo(other.kind) != 0)
        {
            return kind.compareTo(other.kind);
        }        
        else if(Double.compare(this.age, other.age) != 0)
        {
            return -1 * Double.compare(this.age, other.age);
        }
        else
        {
            return name.compareTo(other.name);
        }
    }
}
