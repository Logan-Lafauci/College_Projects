/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shelterproject;

import java.util.*; 

public class Shelter {
    private String shelterName;
    private ArrayList<Animal> animals;
    
    //This is the constructor 
    public Shelter(String name)
    {
        shelterName = name;
        animals = new ArrayList<Animal>();
    }
    
    //This adds new animals created with the animal class
    public void addAnimal(Animal pet)
    {
        animals.add(pet);
    }
    
    //This prints out a list of all the animals added to the animal list along with the name of the shelter 
    public void listAnimals()
    {
        Collections.sort(animals);
        
        System.out.println("Welcome to " + shelterName + " Shelter");
        System.out.println("===================================");
        System.out.printf("%-10s%-15s%-10s\n", "Kind", "Age", "Name");
        System.out.println("-----------------------------------");
        for(Animal pet : animals)
        {
            pet.printInfo();
        }
        System.out.println("-----------------------------------");
    }
}
