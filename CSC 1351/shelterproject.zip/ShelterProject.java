//Student Name: Logan Lafauci
//LSU ID: llafau1
//Lab Section: 1
//Assignment: Shelter project
//Submission Time: 6:15
package shelterproject;

/**
 *
 * @author llafau1
 */
public class ShelterProject {

    public static void main(String[] args) {
        Shelter shltr = new Shelter("Pet Haven");
        
        shltr.addAnimal(new Animal("Muffins", "Dog", 5));
        shltr.addAnimal(new Animal("Charlie", "Cat", 1.5));
        shltr.addAnimal(new Animal("Spot", "Rabbit", 3.5));
        shltr.addAnimal(new Animal("Dexter", "Rabbit", 0.75));
        shltr.addAnimal(new Animal("Bluex", "Dog", 0.5));
        
        shltr.listAnimals();
    }
    
}
