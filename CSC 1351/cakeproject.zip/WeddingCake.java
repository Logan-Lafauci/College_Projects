/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cakeproject;

/**
 *
 * @author llafau1
 */
public class WeddingCake extends Cake
{
    private String bridesFirstName;
    private String groomsFirstName;
    
    //This is a constructor for a wdding cake
    public WeddingCake(String type, int layers, double cost, String womansName, String mansName)
    {
        super(type, layers, cost);
        bridesFirstName = womansName;
        groomsFirstName = mansName;
    }
    
    //This prints out a thank you card to the couple
    public void printCard()
    {
        System.out.printf("Happy Wedding to %s and %s!\n", bridesFirstName, groomsFirstName);
        super.printCard();
    }
}
