/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cakeproject;

/**
 *
 * @author llafau1
 */
public class Cake 
{
    
    private String flavor;
    private int tiers;
    private double price;
    
    //This is a constuctor for the cake
    public Cake(String type, int layers, double cost)
    {
        flavor = type;
        tiers = layers;
        price = cost;
    }
    
    //This prints out the information retaining to the cake
    public void printInvoice()
    {
        System.out.printf("A %d tier %s cake. The price is $%.2f. Issued on: %s\n" , tiers, flavor, price, java.time.LocalDate.now());
    }
    
    //This prints out a thank you car to the customer
    public void printCard()
    {
        System.out.println("Thank you for choosing us!");
    }
}
