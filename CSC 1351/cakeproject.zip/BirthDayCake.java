package cakeproject;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author llafau1
 */
public class BirthDayCake extends Cake
{
    
    private String firstName;
    private int age;
    
    //This is a constuctor for a birthday cake
    public BirthDayCake(String type, int layers, double cost, String name, int age)
    {
        super(type, layers, cost);
        firstName = name;
        this.age = age;
    }
    
    //This prints out a thank you card for the customers birthday
    public void printCard()
    {
        System.out.printf("Happy Birthday to %s! You just turned %d :)\n", firstName, age);
        super.printCard();
    }
}
