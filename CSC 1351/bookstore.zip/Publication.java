/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookstore;

/**
 *
 * @author logan
 */
import java.util.*;

enum Publisher{ELSEVIER, SPRINGER, IEEE, TAYLORFRANCIS, WILEY, ACM};

public class Publication implements Citable, Comparable<Publication>{
    
    private ArrayList<Author> authors = new ArrayList<>();
    private Publisher publisher;
    private String venue;
    private String title;
    protected int startingPage;
    protected int endPage;
    protected int year;
    private String acronym = "";
    private String publish;
    
    public Publication(ArrayList<Author> authorList, String title, String venue, int startingPage, int endPage, int year, String publish)
    {
        authors = authorList;
        this.title = title;
        this.venue = venue;
        this.startingPage = startingPage;
        this.endPage = endPage;
        this.year = year;
        this.publish = publish;
    }
    
    //compares author name, venue, then the year if the previous are the same
    public int compareTo(Publication other)
    {
        if(authors.get(0).lastName.compareTo(other.authors.get(0).lastName) != 0)
        {
            return authors.get(0).lastName.compareTo(other.authors.get(0).lastName);
        }
        else if(venue.compareTo(other.venue) != 0)
        {
            return venue.compareTo(other.venue);
        }
        else
        {
            return Integer.compare(year, other.year);
        }
    }
    
    //used to get valid publishers from the enumeration
    private Publisher getPublisher(String pub)
    {
        try {return Publisher.valueOf(pub.toUpperCase());}
        catch (IllegalArgumentException e){throw e; }
    }
    
    //puts all info in the right citing 
    @Override 
    public String Cite()
    {
        String citing = "";
        //this creates the correct output fot the authors depending on how many authors there are
        Collections.sort(authors);
        if(authors.size() > 2)
        {
            for(int i = 0; i < authors.size() - 1; i++)
            {
                citing += authors.get(i).firstName.charAt(0) + ". " + authors.get(i).lastName + ", ";
            }
            citing += "and " + authors.get(authors.size()-1).firstName.charAt(0) + ". " + authors.get(authors.size()-1).lastName + ", ";
        }
        else if(authors.size() == 2)
        {
            citing += authors.get(authors.size()-2).firstName.charAt(0) + ". " + authors.get(authors.size()-2).lastName + " and " + authors.get(authors.size()-1).firstName.charAt(0) + ". " + authors.get(authors.size()-1).lastName + ", ";
        }
        else
        {
            citing += authors.get(0).firstName.charAt(0) + ". " + authors.get(0);
        }
        
        citing += "\"" + title + "\", ";
        String[] venueName = venue.split(" ");
        //this creates the acronym for the venue
        for(String name: venueName)
        {
            acronym += name.toUpperCase().charAt(0);
        }
        
        citing += venue + " (" + acronym + "), ";
        citing += getPublisher(publish) + ", ";
        return citing;
    }
    
}
