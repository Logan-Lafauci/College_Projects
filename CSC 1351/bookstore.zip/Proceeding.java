/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookstore;

import java.util.ArrayList;

/**
 *
 * @author logan
 */
public class Proceeding extends Publication{
    
    private String city;
    
    public Proceeding(ArrayList<Author> authorList, String title, String venue, int startingPage, int endPage, int year, String publish, String city)
    {
        super(authorList, title, venue, startingPage, endPage, year, publish);
        this.city = city;
    }
    
    //puts all info in the right citing 
    @Override
    public String Cite()
    {
        String citing = super.Cite();
        citing += city + ", " + year + ", pp:" + startingPage + "-" + endPage;
        return citing;
    }
}
