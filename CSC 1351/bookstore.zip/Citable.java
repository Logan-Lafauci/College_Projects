package bookstore;

//The interface Citable 
public interface Citable {
    
    String Cite(); 
}
