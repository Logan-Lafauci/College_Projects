/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookstore;

import java.util.ArrayList;

/**
 *
 * @author logan
 */
public class Journal extends Publication{
    
    private int volume;
    private int number;
    
    public Journal(ArrayList<Author> authorList, String title, String venue, int startingPage, int endPage, int year, String publish, int volume, int number)
    {
        super(authorList, title, venue, startingPage, endPage, year, publish);
        this.volume = volume;
        this.number = number;
    }
    
    //puts all info in the right citing 
    @Override
    public String Cite()
    {
        String citing = super.Cite();
        citing += volume + "(" + number + "): " + startingPage + "-" + endPage + ", " + year;
        return citing;
    }
    
}
