function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(255);
  noStroke();
  fill(0, 0, 255, 85);
  circle(150, 250, 200);
  fill(0, 255, 0, 85);
  circle(200, 150, 200);
  fill(255, 0, 0, 85);
  circle(250, 250, 200);
}