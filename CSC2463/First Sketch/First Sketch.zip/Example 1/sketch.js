function setup() {
  createCanvas(800, 400);
}

function draw() {
  background(0, 255, 0);
  circle(200, 200, 350);
  square(425, 30, 340);
}